const {onRequest}=require('firebase-functions/v2/https');
const {onSchedule}=require('firebase-functions/v2/scheduler');
const admin=require('firebase-admin');
const crypto=require('crypto');
admin.initializeApp();
const db=admin.firestore();

exports.installPromptGate=onRequest({cors:true,region:'us-central1'},async(req,res)=>{
  if(req.method!=='POST')return res.status(405).json({error:'method-not-allowed'});
  const ip=(req.headers['x-forwarded-for']||req.ip||'unknown').toString().split(',')[0].trim();
  const key=crypto.createHash('sha256').update(ip).digest('hex');
  const ref=db.collection('installPromptViews').doc(key);
  let allow=false,count=0;
  await db.runTransaction(async tx=>{const snap=await tx.get(ref);count=snap.exists?Number(snap.data().count||0):0;if(count<3){allow=true;count++;tx.set(ref,{count,updatedAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true});}});
  res.json({allow,count});
});

exports.dailyClientSummary=onSchedule({schedule:'0 21 * * *',timeZone:'America/Mexico_City',region:'us-central1'},async()=>{
  const now=new Date();
  const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Mexico_City',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now).reduce((a,p)=>(a[p.type]=p.value,a),{});
  const start=new Date(`${parts.year}-${parts.month}-${parts.day}T00:00:00-06:00`).getTime();
  const end=start+86400000;
  const clients=await db.collection('clients').where('createdAt','>=',start).where('createdAt','<',end).get();
  if(clients.empty)return;
  const tokens=await db.collection('notificationTokens').get();
  const active=tokens.docs.map(d=>d.data()).filter(x=>x.token&&x.mode==='all'&&(!x.pauseUntil||x.pauseUntil<=Date.now())).map(x=>x.token);
  if(!active.length)return;
  const count=clients.size;
  const message={notification:{title:'Resumen diario · Gestor Pro',body:`Hoy se registraron ${count} ${count===1?'persona':'personas'}.`},data:{url:'./index.html'}};
  for(let i=0;i<active.length;i+=500)await admin.messaging().sendEachForMulticast({...message,tokens:active.slice(i,i+500)});
});
